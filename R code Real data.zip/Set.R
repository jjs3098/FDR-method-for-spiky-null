### 0. Setting ----
library("openxlsx")
setwd("C:/Users/Administrator/Desktop/Real data/...")
source("real_func.R")
source("real_flex.R")

seeds<-208907;
set.seed(seeds)
q_value<-c(0.01, 0.05, 0.1, 0.2) ## q_value

### 1. Load data & Hyper parameter ----
### 1.1 Load peony-data ----
Set4_data<-read.csv("data/set4data.csv",encoding = "UTF-8")
Set_data<-read.csv("data/set1_5_15.csv",encoding = "UTF-8")

# Set<-Set_data[,c(2,3)];  DC<-c(-3,3);bre<-300; main<-"Set 1"  ### refer to 1.2 
Set<-Set4_data[,c(1,2)]; DC<-c(-3,3);bre<-200; main<-"Set 4"
# Set<-Set_data[,c(2,4)];  DC<-c(-2,2);bre<-200; main<-"Set 5"
# Set<-Set_data[,c(2,5)];  DC<-c(-3,3);bre<-300; main<-"Set 1 & 5"

Set<-Set[!is.na(Set[,2]),]
GeneID<-Set[order(Set[,2]),1]
Zval<-Set[order(Set[,2]),2]

n_row<-length(Zval);

### 1.2 hyper parameter ----
## DC is the criterion for removing outliers.
## bre is the number of breaks in the discretization of the z-score axis
df<-20; ## df is the degrees of freedom for fitting the estimated density full data
ours_method<-1; ## finding initial parameter. /1: E-M method /2: Q-Q Method


### 2. Methodology
### 2.1 Efron's local fdr
Efron_res<-locfdr(trn(Zval,DC),bre=bre,df=df,plot=1)

### 2.2 Ramos's local fdr
dengenres<-dengen(Zval,DC=DC,bre=bre,df=df,trunc = 1);
aax<-dengenres[,1];
den<-dengenres[,2];
remanres<-dengenres[,3];
initialc<-0.5
initialres<-simn(Zval,initialc);

nmaxima<-2;
afac<-0;
while(nmaxima>1){
  afac<-afac+0.2;
  initialc<-(0.8+afac)*sqrt(min(initialres[4],initialres[6]));
  c<-cpick(Zval,c=initialc,inc=bre/2,end=1.5);
  result<-simnstep1(Zval,c);
  p4mod<- lm(result[,2] ~ result[,1] + I(result[,1]^2) + I(result[,1]^3)+I(result[,1]^4));
  p4coef<-rev(as.vector(p4mod$coefficients));
  p3coef<-c(4*p4coef[1],3*p4coef[2],2*p4coef[3],p4coef[4]);
  p3roots<-cubic(p3coef);
  p2coef<-c(3*p3coef[1],2*p3coef[2],p3coef[3]);
  plot(result[,1],result[,2]);
  curve(p4func(x,c=p4coef),add=TRUE);
  testmat<-rbind(p3roots,p2func(p3roots,c=p2coef));
  nmaxima<-0;
  for(j in 1:3){
    if(is.numeric(testmat[1,j])&as.numeric(testmat[1,j])>min(result[,1])&as.numeric(testmat[1,j])<max(result[,1])&as.numeric(testmat[2,j])<0){nmaxima<-nmaxima+1;}
  }
  if(p3func(x=c[1],c=p3coef)<0&p3func(x=c[2],c=p3coef)<0&p3func(x=c[3],c=p3coef)<0&p3func(x=c[4],c=p3coef)<0){nmaxima<-nmaxima+1;}
  cat(afac,"\n")
}
if(max(result[,2])-max( result[,2][result[,2]!=max(result[,2])] )>100){result<-result[result[,2]!=max(result[,2]),];}

Ramos_res<-bestfind(result);
Ramos_fdr<-mylocfdr2(Zval,Ramos_res);


### 2.3 Ours local fdr ----
### 2.3.1 KDE
kernel_result<-kernel_func(trn(Zval,DC),r=2^12) ## KDE function
aax_kernel<-kernel_result[,1] ## class marker
den_kernel<-kernel_result[,2] ## density
remanres_kernel<-reman(aax_kernel,den_kernel) ## riemann integral (relative frequency)

### 2.3.2 Peak detection 
cutoff<-Find_cutoff(Zval,k=1.645,kernel_r = kernel_result)
para<-Truncated(Zval,low1=cutoff[2,1],up1=cutoff[2,2],low2=cutoff[2,3],up2=cutoff[2,4],
                low3=cutoff[2,5],up3=cutoff[2,6],low4=cutoff[2,7],up4=cutoff[2,8]) 
cutoff[2,c(9,10)]<-cbind(para[[2]],para[[3]])

### 2.3.3 FDR Estimation
Ours_res<-fdr_func(Zval, cutoff=cutoff,n=n_row) ### phi0/ fdr/ Supplementary
Ours_fdr<-Ours_res[[2]] ### [[2]] : Poisson / [[3]][,5] : kernel


### 3. Numerical Result ----
### 3.1 Enviroment for result ----
Est<-matrix(0,nrow=3,ncol=6) ## Parameter Estimates Table
Reject_local<-matrix(0,6,length(q_value)) ## Number of rejected hypotheses in local fdr
Reject_tail<-matrix(0,6,length(q_value)) ## Number of rejected hypotheses in tail-area fdr
Threshold_local<-matrix(0,3,length(q_value)*2) ## The corresponding test statistic at a given fdr value (local)
Threshold_tail<-matrix(0,3,length(q_value)*2) ## The corresponding test statistic at a given fdr value (tail-area)

Efron_index_local<-list() ## Index of rejected hypothesis
Efron_index_tail<-list() ## Index of rejected hypothesis
Ramos_index_local<-list() ## Index of rejected hypothesis
Ramos_index_tail<-list() ## Index of rejected hypothesis
Ours_index_local<-list() ## Index of rejected hypothesis
Ours_index_tail<-list() ## Index of rejected hypothesis


### 3.1 Parameter Estimation ----
Est[1,]<-c(Efron_res$fp0[3, c(3,1)],Efron_res$fp0[3,2]^2,NA,NA,NA)
Est[2,]<-c(Ramos_fdr[1,3],Ramos_res[3:7])
Est[3,]<-c(Ours_res[[1]][1],c(cutoff[2,9],cutoff[2,10]^2),NA,NA,NA)
Est<-round(Est,5)
colnames(Est)<-c("Phi0","Mean01","Var01","Mean02","Var02","Eta")
rownames(Est)<-c("Efron","Ramos","DT")


### 3.2 data counts of bins
counts<-rbind(n_row,sum(Zval<cutoff[2,1]),sum(Zval>cutoff[2,1] & Zval<cutoff[2,2]),
              sum(Zval>cutoff[2,2] & Zval<cutoff[2,3]),sum(Zval>cutoff[2,3] & Zval<cutoff[2,4]),
              sum(Zval>cutoff[2,4] & Zval<cutoff[2,5]),sum(Zval>cutoff[2,5] & Zval<cutoff[2,6]),
              sum(Zval>cutoff[2,6] & Zval<cutoff[2,7]),sum(Zval>cutoff[2,7] & Zval<cutoff[2,8]),
              sum(Zval>cutoff[2,8]))

rownames(counts)<-c("n",paste("(-Inf,",cutoff[2,1],")" ,sep=""),paste("[",cutoff[2,1],",",cutoff[2,2],")" ,sep=""),
                    paste("[",cutoff[2,2],",",cutoff[2,3],")" ,sep=""),paste("[",cutoff[2,3],",",cutoff[2,4],")" ,sep=""),
                    paste("[",cutoff[2,4],",",cutoff[2,5],")" ,sep=""),paste("[",cutoff[2,5],",",cutoff[2,6],")" ,sep=""),
                    paste("[",cutoff[2,6],",",cutoff[2,7],")" ,sep=""),paste("[",cutoff[2,7],",",cutoff[2,8],")" ,sep=""),
                    paste("[",cutoff[2,8],", Inf)" ,sep=""))

### 3.3 Number of Rejection & cut point ----
remanres_left<-c();remanres_right<-c();
for(i in 1:n_row){remanres_left[i]<-lookup(Zval[i],aax,cumsum(remanres))};
for(i in 1:n_row){remanres_right[i]<-lookup(Zval[i],aax,rev(cumsum(rev(remanres))))};

Efron_fdr_left<-Est[1,1]*pnorm(Zval,Est[1,2],sqrt(Est[1,3]))/remanres_left
Efron_fdr_right<-Est[1,1]*pnorm(Zval,Est[1,2],sqrt(Est[1,3]),lower.tail = F)/remanres_right

Ramos_fdr_left<-Est[2,1]*{pnorm(Zval,Est[2,2],sqrt(Est[2,3]))*Est[2,6]+
    pnorm(Zval,Est[2,4],sqrt(Est[2,5]))*(1-Est[2,6])}/remanres_left
Ramos_fdr_right<-Est[2,1]*{pnorm(Zval,Est[2,2],sqrt(Est[2,3]),lower.tail = F)*Est[2,6]+
    pnorm(Zval,Est[2,4],sqrt(Est[2,5]),lower.tail = F)*(1-Est[2,6])}/remanres_right

Ours_fdr_left<- Est[3,1]*pnorm(Zval,Est[3,2],sqrt(Est[3,3]))/remanres_left
Ours_fdr_right<- Est[3,1]*pnorm(Zval,Est[3,2],sqrt(Est[3,3]),lower.tail = F)/remanres_right

### 3.3.1 Loval fdr & Tail-are fdr
for(i in c(1:length(q_value))){
  ## Local fdr
  Efron_local_left<-if(length(head(which(Efron_res$fdr>q_value[i]),1))==0){0}else{
    head(which(Efron_res$fdr>q_value[i]),1)-1+sum(DC[1]>Zval) }
  
  Efron_local_right<-if(length(tail(which(Efron_res$fdr>q_value[i]),1))==0){n_row+1} else {
    tail(which(Efron_res$fdr>q_value[i]),1)+1+sum(DC[1]>Zval) }
  
  Ramos_local_left<-if(length(tail(which(Zval<(-initialc) & Ramos_fdr[,2] <q_value[i]),1))==0) {0} else {
    tail(which(Zval<(-initialc) & Ramos_fdr[,2] <q_value[i]),1)}
  Ramos_local_right<-if(length(head(which(Zval>(initialc) & Ramos_fdr[,2]<q_value[i]),1))==0){n_row+1}else{
    head(which(Zval>(initialc) & Ramos_fdr[,2]<q_value[i]),1) }
  
  Ours_local_left<-if(length(tail(which(Zval<cutoff[2,3] & Ours_fdr<q_value[i]),1))==0){0}else{
    tail(which(Zval<cutoff[2,3] & Ours_fdr<q_value[i]),1) }
  Ours_local_right<-if(length(head(which(Zval>cutoff[2,5] & Ours_fdr<q_value[i]),1))==0){n_row+1}else{
    head(which(Zval>cutoff[2,5] & Ours_fdr<q_value[i]),1) }
  
  Reject_local[,i]<-c(Efron_local_left, n_row-Efron_local_right+1,
                      Ramos_local_left, n_row-Ramos_local_right+1,
                      Ours_local_left, n_row-Ours_local_right+1)
  
  Threshold_local[1:3,c(i*2-1,i*2)]<-round(rbind(Zval[c(Efron_local_left,Efron_local_right)],
                                                 Zval[c(Ramos_local_left,Ramos_local_right)],
                                                 Zval[c(Ours_local_left,Ours_local_right)]),4)
  
  
  ## Tail-area fdr
  Efron_tail_left<-if(length(tail(which(Efron_fdr_left< q_value[i]/2),1))==0){ 0 } else {
    tail(which(Efron_fdr_left< q_value[i]/2),1) }
  Efron_tail_right<-if(length(head(which(Efron_fdr_right< q_value[i]/2),1))==0){n_row+1}else{
    head(which(Efron_fdr_right< q_value[i]/2),1) }
  Ramos_tail_left<-if(length(tail(which(Zval<(-initialc) & Ramos_fdr_left<q_value[i]/2),1))==0) {0} else {
    tail(which(Zval<(-initialc) & Ramos_fdr_left<q_value[i]/2),1)}
  Ramos_tail_right<-if(length(head(which(Zval>(initialc) & Ramos_fdr_right<q_value[i]/2),1))==0){n_row+1}else{
    head(which(Zval>(initialc) & Ramos_fdr_right<q_value[i]/2),1)}
  Ours_tail_left<-if(length(tail(which(Zval<cutoff[2,3] & Ours_fdr_left<q_value[i]/2),1))==0){0}else{
    tail(which(Zval<cutoff[2,3] & Ours_fdr_left<q_value[i]/2),1) }
  Ours_tail_right<-if(length(head(which(Zval>cutoff[2,5] & Ours_fdr_right<q_value[i]/2),1))==0){n_row+1}else{
    head(which(Zval>cutoff[2,5] & Ours_fdr_right<q_value[i]/2),1) }
  
  
  Reject_tail[,i]<-c(Efron_tail_left, n_row-Efron_tail_right+1,
                     Ramos_tail_left, n_row-Ramos_tail_right+1,
                     Ours_tail_left, n_row-Ours_tail_right+1)
  Threshold_tail[1:3,c(i*2-1,i*2)]<-round(rbind(Zval[c(Efron_tail_left,Efron_tail_right)],
                                                Zval[c(Ramos_tail_left,Ramos_tail_right)],
                                                Zval[c(Ours_tail_left,Ours_tail_right)]),4)
  
  
}
colnames(Reject_local)<-q_value
colnames(Reject_tail)<-q_value
rownames(Reject_local)<-paste(rep(c("Efron","Ramos","DT"),each=2),rep(c("(Left)","(Right)"),2),sep="")
rownames(Reject_tail)<-paste(rep(c("Efron","Ramos","DT"),each=2),rep(c("(Left)","(Right)"),2),sep="")

colnames(Threshold_local)<-rep(q_value,each=2)
colnames(Threshold_tail)<-paste(rep(q_value,each=2),"(",rep(c("Left","Right"),length(q_value)),")",sep="")
rownames(Threshold_local)<-c("Efron","Ramos","DT")
rownames(Threshold_tail)<-c("Efron","Ramos","DT")

### 4. plot
par(mfrow=c(1,1))
bre_hist<-1000
if( any(c("Set 1", "Set 1 & 5") == main)){
  limx_hist<-c(-1.5,1.5);
  limx_fdr<-c(-2,2); limx_fdr_L<-c(-1.5,1); limx_fdr_R<-c(-1,1.5)
  limy<-c(0,2.5);
} else{
  limx_hist<-c(-1, 1);
  limx_fdr<-c(-1.5, 1.5); limx_fdr_L<-c(-1, 0.5); limx_fdr_R<-c(-0.5, 1)
  limy<-c(0,5);bre_hist<-2000
}


### 4.1 Histogram
### 4.1.1 Histogram(Init)
par(mfrow=c(1,1))
hist(Zval,bre,xlim=limx_hist,freq=F,xlab="test-stat",main=main,ylim=limy,
     cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white",yaxs="i",bre=bre_hist)

# abline(v=cutoff[1,7],lwd=2,lty=4);abline(v=cutoff[1,8],lwd=2,lty=4);
abline(v=cutoff[1,5],lwd=2,lty=4);abline(v=cutoff[1,6],lwd=2,lty=4);
abline(v=cutoff[1,3],lwd=2,lty=4);abline(v=cutoff[1,4],lwd=2,lty=4);
# abline(v=cutoff[1,1],lwd=2,lty=4);abline(v=cutoff[1,2],lwd=2,lty=4);
lines(aax,dnorm(aax,Est[3,2],sqrt(Est[3,3]))*(Est[3,1]),col=4,lwd=3,lty=1)


### 4.1.2 Histogram
hist(Zval,bre,xlim=limx_hist,freq=F,xlab="test-stat",main=main,ylim=limy,
     cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white",yaxs="i",bre=bre_hist)

# abline(v=cutoff[2,7],lwd=2,lty=4);abline(v=cutoff[2,8],lwd=2,lty=4);
abline(v=cutoff[2,5],lwd=2,lty=4);abline(v=cutoff[2,6],lwd=2,lty=4);
abline(v=cutoff[2,3],lwd=2,lty=4);abline(v=cutoff[2,4],lwd=2,lty=4);
abline(v=cutoff[2,1],lwd=2,lty=4);abline(v=cutoff[2,2],lwd=2,lty=4);

lines(aax,dnorm(aax,Est[3,2],sqrt(Est[3,3]))*Est[3,1],col=4,lwd=3,lty=1)
lines(aax,{dnorm(aax,Est[2,2],sqrt(Est[2,3]))*Est[2,6]+
    dnorm(aax,Est[2,4],sqrt(Est[2,5]))*(1-Est[2,6])}*Est[2,1],col=3,lwd=3,lty=3 )
lines(aax,dnorm(aax,Est[1,2],sqrt(Est[1,3]))*Est[1,1],lwd=3,lty=2,col=2)
legend("topright", legend = c("DT","Ramos","Efron","Cutoff"),col=c(4:1),lty = c(1,3,2,4),cex=1
       ,xpd=T, lwd=2)

# set.5
# text(-0.43,3,expression(Iota[1]),font = 1, cex = 1.5)
# text(-0.2,3,expression(Iota[2]),font = 1, cex = 1.5)
# text(0.28,3,expression(Iota[3]),font = 1, cex = 1.5)
# set.1
text(-0.49,1.5,expression(Iota[1]),font = 1, cex = 1.5)
text(0.65,1.5,expression(Iota[2]),font = 1, cex = 1.5)


### 4.2 f
hist(Zval,bre,freq=F,ylim=c(0,1.5),xlim = limx_fdr,col="white")
lines(aax,den,lwd=2,col=1)


### 4.3 local fdr
plot(aax,pmin(dnorm(aax,Est[3,2],sqrt(Est[3,3]))*Est[3,1]/den,1),
     xlim=limx_fdr,ylim=c(0,1.001),type="l",
     xlab="test-stat",ylab="fdr",main=main,
     cex.axis=1.5,cex.main=2,cex.lab=1.5,yaxs="i",lwd=2,col=4)

lines(aax,pmin(Est[2,1]*{dnorm(aax,Est[2,2],sqrt(Est[2,3]))*Est[2,6]+
    dnorm(aax,Est[2,4],sqrt(Est[2,5]))*(1-Est[2,6])}/den,1),
    xlim=limx_fdr,ylim=c(0,1.001),lwd=2,col=3,lty=3)

lines(aax,pmin(dnorm(aax,Est[1,2],sqrt(Est[1,3]))*Est[1,1]/den,1),
      xlim=limx_fdr,ylim=c(0,1.001),lwd=2,col=2,lty=2)

legend("topright", legend = c("DT","Ramos","Efron"),col=c(4:2),lty = c(1,3,2),cex=2
       ,xpd=T, lwd=2)  

# abline(h=0.1,lwd=1,col=1,lty=1)
# abline(h=0.05,lwd=1,col=1,lty=1)
# abline(h=0.01,lwd=1,col=1,lty=1)

### 4.3 Global fdr
### 4.3.1 Left
par(mfrow=c(1,2))
plot(aax,pmin(pnorm(aax,Est[3,2],sqrt(Est[3,3]))*Est[3,1]/cumsum(remanres),1),
     xlim=limx_fdr_L,ylim=c(0,1.001),type="l",
     xlab="test-stat",ylab="Fdr(Left)",main=main,
     cex.axis=1.5,cex.main=2,cex.lab=1.5,yaxs="i",lwd=2,col=4)

lines(aax,pmin(Est[2,1]*{pnorm(aax,Est[2,2],sqrt(Est[2,3]))*Est[2,6]+
    pnorm(aax,Est[2,4],sqrt(Est[2,5]))*(1-Est[2,6])}/cumsum(remanres),1),
    xlim=limx_fdr_L,ylim=c(0,1.001),lwd=2,col=3,lty=3)

lines(aax,pmin(pnorm(aax,Est[1,2],sqrt(Est[1,3]))*Est[1,1]/cumsum(remanres),1),
      xlim=limx_fdr_L,ylim=c(0,1.001),lwd=2,col=2,lty=2)

legend("topleft", legend = c("DT","Ramos","Efron"),col=c(4:2),lty = c(1,3,2),cex=2
       ,xpd=T, lwd=2)  
# abline(h=0.1/2,lwd=1,col=1,lty=1)
# abline(h=0.05/2,lwd=1,col=1,lty=1)
# abline(h=0.01/2,lwd=1,col=1,lty=1)

### 4.3.2 Right
plot(rev(aax),pmin(pnorm(rev(aax),Est[3,2],sqrt(Est[3,3]),lower.tail = F)*Est[3,1]/cumsum(rev(remanres)),1),
     xlim=limx_fdr_R,ylim=c(0,1.001),type="l",
     xlab="test-stat",ylab="Fdr(Right)",main=main,
     cex.axis=1.5,cex.main=2,cex.lab=1.5,yaxs="i",lwd=2,col=4)

lines(rev(aax),pmin(Est[2,1]*{pnorm(rev(aax),Est[2,2],sqrt(Est[2,3]),lower.tail = F)*Est[2,6]+
    pnorm(rev(aax),Est[2,4],sqrt(Est[2,5]),lower.tail = F)*(1-Est[2,6])}/cumsum(rev(remanres)),1),
    xlim=limx_fdr_R,ylim=c(0,1.001),lwd=2,col=3,lty=3)

lines(rev(aax),pmin(pnorm(rev(aax),Est[1,2],sqrt(Est[1,3]),lower.tail = F)*Est[1,1]/cumsum(rev(remanres)),1),
      xlim=limx_fdr_R,ylim=c(0,1.001),lwd=2,col=2,lty=2)

legend("topright", legend = c("DT","Ramos","Efron"),col=c(4:2),lty = c(1,3,2),cex=2
       ,xpd=T, lwd=2)  

# abline(h=0.1/2,lwd=1,col=1,lty=1)
# abline(h=0.05/2,lwd=1,col=1,lty=1)
# abline(h=0.01/2,lwd=1,col=1,lty=1)
par(mfrow=c(1,1))

### 4.5 differentiated kernel density
par(mfrow=c(1,1))

plot(kernel_result[,1] ,kernel_result[,2],xlim=limx_hist,type="l",
     main="KDE",ylab="Density",xlab="test-stat",
     cex.axis=1.5,cex.main=2,cex.lab=1.5,lwd=1)
abline(v=c(cutoff[2,4],cutoff[2,5]),lty=4);
abline(v=c(cutoff[2,2],cutoff[2,3]),lty=4);

# plot(kernel_result[,1] ,kernel_result[,3],xlim=limx_hist,type="l",
#      main="Differentiated KDE(Init)",ylab="Density",xlab="test-stat",
#      cex.axis=1.5,cex.main=2,cex.lab=1.5,lwd=1)
# abline(v=c(cutoff[1,4],cutoff[1,5]),lty=4);abline(h=c(cutoff[2,11],-cutoff[2,11]),lty=3);

plot(kernel_result[,1] ,kernel_result[,3],xlim=limx_hist,type="l",
     main="Differentiated KDE",ylab="Density",xlab="test-stat",
     cex.axis=1.5,cex.main=2,cex.lab=1.5,lwd=1)
abline(v=c(cutoff[2,4],cutoff[2,5]),lty=4);abline(h=c(cutoff[2,11],-cutoff[2,11]),lty=3);
# points(cutoff[2,2],cutoff[2,11],pch ="*",col=4,cex=3)
points(cutoff[2,4],cutoff[2,11],pch ="*",col=4,cex=3)
points(cutoff[2,5],-cutoff[2,11],pch ="*",col=4,cex=3)
par(mfrow=c(1,1))


###----
# Est
Reject_local
Reject_tail
# Threshold_local
# Threshold_tail
# cutoff
# c("Ramos.a"=initialc,"Ramos"=Ramos_res[1])
# counts



