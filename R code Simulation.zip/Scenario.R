### Title : Development of a new Local FDR control methodology using Truncated MLE
### source & library & default
setwd("C:/Users/ADMIN/Desktop/Truncated MLE 논문/Truncated MLE(07.05)/Scenario")
source("Scenario_func.R")
source("functions_for_flex_fixed.R")
seed<-208907; rep<-100

### 1. Parameter
### 1.1 Scenario parameter-1
n<-10000; g1<-20;g2<-20; ### n, g1, g2 : Hypothesis, normal group, abnormal group
alpha<-0.2; side<-2; bre<-200; ### bre : histogram bin

### 1.2 Scenario parameter-2
# mu_peak<-0; se_peak<-0; p_peak<-0;
# mu_alter<-2.5; se_alter<-0.7; p_alter<-0; 
# mu_null<-0; se_null<-1;
# trn_null<-F
para_generate(Sim_n = 5)

### 1.3 Range for Density Estimation
if(p_alter == 0){DC<-3} else
  if(side==2){DC<-mu_alter+2*se_alter} else 
    {DC<- c(-mu_alter,mu_alter+2*se_alter)} 


### 2. Result variables
### 2.1 Scenario table
Zval_m<-list()
n_trunc<-c() ## number of truncated simulation
kernel_result<-list()

### 2.2 Parameter Estimation list
### 2.2.1 Ours : Threshold(c1, a1, a2, c2), mu_null, se_null
cutoff<-list()
pval_our<-matrix(0,nrow=rep,ncol=3)
### 2.2.2 Ramos
bestfindres<-matrix(0,nrow=rep,ncol=9) 
dengenres<-list()
### 2.2.3 Efron
para_efron<-matrix(0,nrow=rep,ncol=3) 

### 2.3 Local-fdr list : Zval, fdr, phi0
fdrres_our<-list() 
fdrres_ramos<-list()
fdrres_efron<-list()

### 2.4 Result summary list : FDR, TPR, TNR, FD, Rejects
fdrest_our<-matrix(0,nrow=rep,ncol=5) 
fdrest_ramos<-matrix(0,nrow=rep,ncol=5)
fdrest_efron<-matrix(0,nrow=rep,ncol=5)

### 3. Data matrix
for(i in c(1:rep)){
  Zval_m[[i]]<-data_generate(side=side,seed=seed+i-1,trn_null=trn_null)
}

### 4. Estimation for FDR
for(i in c(1:rep)){
  Zval<-Zval_m[[i]][,2]
  
  ### 4.1 Estimation for f density
  ### 4.1.1  Poisson Estimation
  dengenres[[i]]<-dengen(Zval,DC=DC,trunc=T,bre=bre)  ##  |Zval| < DC
  aax<-dengenres[[i]][,1] ##  Class mark
  den<-dengenres[[i]][,2] ##  Class density (=likelihood)
  remanres<-dengenres[[i]][,3] ##  relative frequency

  ### 4.1.2 Kernel Estimation
  kernel_result[[i]]<-kernel_func(Zval)
  aax_kernel<-kernel_result[[i]][,1]
  den_kernel<-kernel_result[[i]][,2]
  remanres_kernel<-reman(aax_kernel,den_kernel)

  ### 4.2 Estimation for f_0, phi_0, fdr (Our)
  ### 4.2.1 Truncated area selection
  cutoff[[i]]<-Find_cutoff(Zval,kernel_r=kernel_result[[i]],method=2)
  if(cutoff[[i]][1,2]==cutoff[[i]][1,3]){n_trunc[i]<-F} else {n_trunc[i]<-T}
  if(cutoff[[i]][1,6] > sd(Zval)*5 | cutoff[[i]][1,6]< sd(Zval)/5){next}  ## for not convergence

  ### 4.2.2 Truncated MLE
  Tr<-Truncated(Zval,cutoff[[i]][2,1],cutoff[[i]][2,2],cutoff[[i]][2,3],cutoff[[i]][2,4])
  cutoff[[i]][2,5]<-Tr[[2]];cutoff[[i]][2,6]<-Tr[[3]]
  if(cutoff[[i]][2,6] > sd(Zval)*5 | cutoff[[i]][2,6] < sd(Zval)/5){next}  ## for not convergence

  ### 4.2.3 fdr
  result_our<-fdr_func(Zval, cutoff=cutoff[[i]],side=side) ## phi_0/ fdr/ Supplementary

  ### 4.2.4 result
  pval_our[i,]<-result_our[[1]][1:3]
  fdrres_our[[i]]<-cbind(Zval,result_our[[2]],rep(pval_our[i,1],n),result_our[[3]][,1])

  ### 4.3 Estimation for f_0, phi_0, fdr (Ramos)
  simdata<-Zval_m[[i]]
  initialc<-uniroot(csolver,c(0,2))$root;
  initialres<-simn(simdata[,2],initialc);
  nmaxima<-2;afac<-0.25
  while(nmaxima>1){
    afac<-afac+0.25;cat("afac = ", afac,"\n")
    initialc<-(0.75+afac)*sqrt(min(initialres[4],initialres[6]));
    c<-cpick(simdata[,2],c=initialc,inc=100,end=2.5)
    result_p<-simnstep1(simdata[,2],c)
    p4mod<- lm(result_p[,2] ~ result_p[,1] + I(result_p[,1]^2) + I(result_p[,1]^3)+I(result_p[,1]^4));
    p4coef<-rev(as.vector(p4mod$coefficients));
    p3coef<-c(4*p4coef[1],3*p4coef[2],2*p4coef[3],p4coef[4]);
    p3roots<-cubic(p3coef);
    p2coef<-c(3*p3coef[1],2*p3coef[2],p3coef[3]);
    # plot(result_p[,1],result_p[,2]);
    # curve(p4func(x,c=p4coef),add=TRUE);
    testmat<-rbind(p3roots,p2func(p3roots,c=p2coef));
    nmaxima<-0;
    for(j in 1:3){
      if(is.numeric(testmat[1,j])&as.numeric(testmat[1,j])>min(result_p[,1])&as.numeric(testmat[1,j])<max(result_p[,1])&as.numeric(testmat[2,j])<0){nmaxima<-nmaxima+1;}
    }
    if(p3func(x=c[1],c=p3coef)<0&p3func(x=c[2],c=p3coef)<0&p3func(x=c[3],c=p3coef)<0&p3func(x=c[4],c=p3coef)<0){nmaxima<-nmaxima+1;}
  }
  if(max(result_p[,2])-max( result_p[,2][result_p[,2]!=max(result_p[,2])] )>100){result_p<-result_p[result_p[,2]!=max(result_p[,2]),];}

  bestfindres[i,]<-c(bestfind(result_p),initialc) ### c / out / Mu01 / Var01 / Mu02 / Var02 / Eta / c / inittial c
  fdrres_ramos[[i]]<-mylocfdr(Zval,bestfindres[i,]) ### test-stat / locfdr / phi0 /  f
  
  ### 4.4 Estimation for f_0, phi_0, fdr (Efron)
  result_efron<-locfdr(trn(Zval,DC),bre=bre,df=45,plot=0)
  para_efron[i,]<-result_efron$fp0[3,] ### Mu01 / SD01 / Phi0
  fdrres_efron[[i]]<-mylocfdr_efron(Zval,para_efron[i,])  ### test-stat / locfdr / Phi0 /
  
  cat("i = ", i,"/",rep,"\n",sep="")
}

for(i in 1:rep){
  ### FDP / TPR / TNR / FP / Reject
  fdrest_our[i,]<-fdrest(Zval_m[[i]],fdrres_our[[i]][,c(1:3)],a=alpha,c=cutoff[[i]],method=1);
  fdrest_ramos[i,]<-fdrest(Zval_m[[i]],fdrres_ramos[[i]][,c(1:3)],a=alpha,method=2);
  fdrest_efron[i,]<-fdrest(Zval_m[[i]],fdrres_efron[[i]],a=alpha,method=2);
}

### Result
fig_num<-1
result_func(table=3)
result_func(fig = 2,data_num=fig_num,
            ylims = c(0,0.5),xlims = c(-4,4),
            ylims2 = c(0,0.15),xlims2 = c(1.5,4))
result_func(fig = 3,data_num=fig_num,
            ylims_fdr = c(0,1.25),xlims_fdr = c(-4,4),
            ylims_fdr2 = c(0,0.5),xlims_fdr2 = c(2,4))
result_func(fig=4,data_num = fig_num,ylims_RMSE = c(0,0.25),ylims = c(0,0.9))
