### Packages
require("kedd") ### Kernel Estimator and Bandwidth Selection for Density and Its Derivatives
require("splines")
require("graphics")
require("truncnorm")
require("locfdr")

### Parameter generate function
### Sim_n : simulation number
para_generate<-function(Sim_n){
  
  ### 1. Null parameter
  mu_null<<-0; se_null<<-1; mu_peak<<-0;
  
  ### 2. Peak & Alternative parameter
  ### 2.1 No alter
  if(Sim_n==1){p_peak<<-0.00; se_peak<<-0.00; p_alter<<-0.00; mu_alter<<-2.5; se_alter<<-0.7; } 
  else if(Sim_n==2){p_peak<<-0.05; se_peak<<-0.10; p_alter<<-0.00; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==3){p_peak<<-0.05; se_peak<<-0.30; p_alter<<-0.00; mu_alter<<-2.5; se_alter<<-0.7; }
  
  ### 2.2 No peak
  else if(Sim_n==4){p_peak<<-0.00; se_peak<<-0.00; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==5){p_peak<<-0.00; se_peak<<-0.00; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  
  ### 2.3 Alternative & normal peak
  else if(Sim_n==6){p_peak<<-0.10; se_peak<<-0.10; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==7){p_peak<<-0.10; se_peak<<-0.20; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==8){p_peak<<-0.10; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==9){p_peak<<-0.30; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==10){p_peak<<-0.50; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==11){p_peak<<-0.10; se_peak<<-0.10; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==12){p_peak<<-0.30; se_peak<<-0.20; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==13){p_peak<<-0.50; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  
  ### 2.4 Alternative & Truncated normal peak
  else if(Sim_n==14){p_peak<<-0.10; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==15){p_peak<<-0.30; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==16){p_peak<<-0.50; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-3.0; se_alter<<-0.7; }
  else if(Sim_n==17){p_peak<<-0.10; se_peak<<-0.10; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==18){p_peak<<-0.30; se_peak<<-0.20; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  else if(Sim_n==19){p_peak<<-0.50; se_peak<<-0.30; p_alter<<-0.10; mu_alter<<-2.5; se_alter<<-0.7; }
  
  if(Sim_n %in% c(14:19)) {trn_null<<-T} else{ trn_null<<-F}
}


### Data generate function
### alter_rate : Proportion of right-side alternative hypothesis
### trn_null : Truncated null(Yes : 0, NO : 1)
### se_trn : Truncated null Range
data_generate<-function(side=side,seed=208907,alter_rate=1/2,trn_null=0,se_trn=3*se_peak){
  
  ### 1. Generate data matrix
  set.seed(seed)
  Zval_m<-matrix(numeric(n*3),nrow=n,ncol=3)
  
  ### 2. Numbers (null, peak, altenative)
  if(side ==1){alter_rate=1}
  counts<-rmultinom(1,n,prob=c(1-p_alter-p_peak,p_peak, p_alter*alter_rate, p_alter*(1-alter_rate)))
  
  ### 3. Data matrix
  Zval_m[,1]<-rep(c(1,0,1,0),counts) ## Null(Non-peak(1) vs peak(0)), Alternative(Right(1) vs Left : (0))
  Zval_m[,3]<-rep(c(0,0,1,1),counts) ## Null(Non-peak(0), peak(0)) vs Alternative(Right(1), Left(1))
  if(trn_null == 0){
    Zval_m[,2]<-c(rnorm(counts[1],mu_null,se_null),rnorm(counts[2],mu_peak,se_peak),
            rnorm(counts[3],mu_alter,se_alter),rnorm(counts[4],-mu_alter,se_alter))
  } else {
    Zval_m[,2]<-c(rnorm(counts[1],mu_null,se_null),
                  rtruncnorm(counts[2],a=-se_trn,b=se_trn,mu_peak,se_peak),
                  rnorm(counts[3],mu_alter,se_alter),rnorm(counts[4],-mu_alter,se_alter))
  }
  
  return(Zval_m)
}


### Kernel Density Estimation function
### bw : bandwidth
### r : number of bins
kernel_func<-function(Zval,bw=NULL,r=2^10){
  set.seed(208907)
  
  ### 1. Band-width selection & Kernel density cutoff
  if (is.null(bw)) {bw<-density(Zval)$bw} ## band width
  range_x<-c(min(Zval)-4*bw,max(Zval)+4*bw)
  range_y<-seq(range_x[1L], range_x[2L],length.out=r)
  
  ### 2. Find cut-point 
  ### 2.1 Kernel density
  Zval_kde<-dkde(Zval, deriv.order = 0,h=bw,y=range_y)
  kde_value<-Zval_kde$eval.points
  kde_est<-Zval_kde$est.fx
  
  ### 2.2 The 1-derivative of Kernel density
  Zval_dkde<-dkde(Zval, deriv.order = 1,h=bw,y=range_y)
  kde_est2<-Zval_dkde$est.fx
  
  ### 3. result
  result<-cbind(kde_value,kde_est,kde_est2)
  return(result)
}

### Function to find critical points
Truncated<- function(data=Zval, low1=-10, up1=up1, low2=low2, up2=10,iter=100,tol=10^(-7),fig=F){
  
  ### 1. Truncated data
  Zval_t<-data[((data>low1) & (data<up1)) | ((data>low2) & (data<up2))];
  n_Zval_t<-length(Zval_t)
  mu<-mean(Zval_t); se<-sd(Zval_t)
  para<-matrix(c(mu,se),ncol=2)
  
  ### 2. Parameter estimation
  for(i in 1:iter){
    
    ### 2.1 Initial value
    mu_break<-mu
    se_break<-se
    
    ### 2.2 Mu
    f<-function (mu) {
      C<-(pnorm(up1,mu,se)-pnorm(low1,mu,se))+(pnorm(up2,mu,se)-pnorm(low2,mu,se))
      C_prime1<-(1/se)*(dnorm((low1-mu)/se)-dnorm((up1-mu)/se)+dnorm((low2-mu)/se)-dnorm((up2-mu)/se))
      
      return(abs((-n_Zval_t)*(C_prime1/C) + (1/se^2)*(sum(Zval_t)-n_Zval_t*mu)))
    }
    # curve(f,from=-4,to=4,ylim=c(-1000,1000)) ## mu plot
    mu<-optimize(f,c(-3,3))$minimum
    
    ### 2.2 SE
    g<-function(se){
      C<-(pnorm(up1,mu,se)-pnorm(low1,mu,se))+(pnorm(up2,mu,se)-pnorm(low2,mu,se))
      C_prime2<-(1/se)*{((low1-mu)/se)*dnorm((low1-mu)/se)-((up1-mu)/se)*dnorm((up1-mu)/se)+
          ((low2-mu)/se)*dnorm((low2-mu)/se)-((up2-mu)/se)*dnorm((up2-mu)/se)}
      
      return( (-n_Zval_t)*(C_prime2/C) - (n_Zval_t)/se +sum((Zval_t-mu)^2)/(se^3))
    }
    # curve(g,from=0.01,to=3,ylim=c(-1500,1000),xlim=c(0,2)) ## SE plot
    xxx<-seq(se/5,3,0.0001);
    se<-uniroot(g,c(se/5,xxx[which.min(g(xxx))]) )$root
    
    ### 2.3 Stop-limit
    para<-rbind(para,c(mu,se))
    if( (abs(mu-mu_break)<tol) & (abs(se-se_break)<tol) ){break;}
  }
  
  ### 3. Truncated histogram
  if(fig==T){hist(Zval_t,nclass=150)}
  
  ### 4. result table
  rownames(para)<-c(1:(i+1));colnames(para)<-c("Mu", "SE")
  result_list<-list(Zval_t,mu,se,para,n_Zval_t)
  names(result_list)<-c("Zval_t","Mu0","SE0","iter","n_Zval_t")
  return(result_list)
}  


### Function to find critical points
### method : SE selection for calculating density_cutoff (1 : max(SE_em), 2: min(1,max(SE_em)), 3: SE_MLE )
### pct : Initial Zero assumption Interval
### k : flexible value [mu-k*SE, mu+k*SE]
### kk : fixed value [mu-kk, mu+kk]
Find_cutoff<-function(Zval,method=1,pct=c(0.05,0.95),k=1.5,kk=0,kernel_r){
  set.seed(208907)
  
  ### 1 Zero assumption area (Initial low1, up2)
  init_low1<-quantile(Zval,pct)[1]
  init_up2<-quantile(Zval,pct)[2]
  
  ### 2. Peak threshold (Find up1, low2)
  ### 2.1 Kernel Estimation
  kernel_ind<-(kernel_r[,1]>init_low1 & kernel_r[,1]<init_up2)
  kde_value<-kernel_r[kernel_ind,1]
  kde_est<-kernel_r[kernel_ind,2]
  kde_est2<-kernel_r[kernel_ind,3]
  
  
  ### 2.2 Calculating density_cutoff
  ### 2.2.1 SE selection
  if(method==1){
    sigma_init<-max(em_ramos(Zval[Zval>init_low1 & Zval<init_up2], mu1=0, mu2=0, sigma1=1.1,
                       sigma2=0.2, phi=0.6, a=init_low1, b=init_up2, iter=100)[3:4])
  }else if(method==2){
    sigma_init<-min(1,max(em_ramos(Zval[Zval>init_low1 & Zval<init_up2], mu1=0, mu2=0, sigma1=1.1,
                                   sigma2=0.2, phi=0.6, a=init_low1, b=init_up2, iter=100)[3:4]))
  }else if(method==3){
    sigma_init<-sd(Zval[Zval>init_low1 & Zval<init_up2])
  }
  ### 2.2.2 Calculating
  density_cutoff<- 1/((sigma_init^2)*sqrt(2*pi*exp(1)))
  
  
  ### 2.3 Find up1, low2
  ### 2.3.1 Peak condition
  up1_cond1<- (kde_value <= kde_value[which.max(kde_est2)])
  up1_cond2<- (tail(which(kde_est2[up1_cond1]<=density_cutoff),1)+1)
  
  low2_cond1<- (kde_value >= kde_value[which.min(kde_est2)])
  low2_cond2<- (head(which(kde_est2[low2_cond1]>=-density_cutoff),1))
  low2_cond3<- which(low2_cond1)[low2_cond2]-1
  
  ### 2.3.2 Definition of peak area
  if(up1_cond1[up1_cond2]==T & low2_cond1[low2_cond3] ==T){
    up1<-kde_value[up1_cond2]; low2<-kde_value[low2_cond3]
  } else {
    up1<-0; low2<-0;
    cat('There are no truncated areas. \n')
  }
  
  if (low2>init_up2){
    if(init_up2>up1){init_up2<-low2} else {up1<-init_up2; low2<-init_up2;}
  } else if (init_low1>up1){
    if(low2>init_low1){init_low1<-up1} else {low2<-init_low1; up1<-init_low1;}
  }
  
  ### 3. Parameter Estimation (Initial Mu_null, SE_null)
  init_par<-Truncated(data=Zval, low1=init_low1, up1=up1, low2=low2, up2=init_up2)
  mu_init<-init_par[[2]];se_init<-init_par[[3]]
  
  ### 4. Zero assumption area (low1, up2) 
  if( (kk==0) & (k!=0)){
    low1<-mu_init-k*se_init; up2<-mu_init+k*se_init
  } else if((kk != 0) & (k==0) ){
    low1<-mu_init-kk; up2<-mu_init+kk
  } else {cat('There are no Zero Assumption areas. \n')}
  
  if((up1>low2)){
    cat('Please enter the constant correctly 2.\n')
    break;
  } else if (low2>up2){
    if(up2>up1){up2<-low2} else {up1<-up2; low2<-up2;}
  } else if (low1>up1){
    if(low2>low1){low1<-up1} else low2<-low1;{up1<-low1;}
  }
  
  ### 2.5 Result matrix
  cutoff_m<-rbind(c(init_low1,up1,low2,init_up2,mu_init,se_init,sigma_init),
                  c(low1,up1,low2,up2,0,0,density_cutoff))
  rownames(cutoff_m)<-c("Initial_point","Truncated_point")
  colnames(cutoff_m)<-c("low1","up1","low2","up2","Mu0","SE0","Density cutoff")
  
  return(cutoff_m)
}

### Function to compute local fdr
### cutoff : result from Find_cutoff function
fdr_func<-function(Zval,cutoff,side=side){
  
  c1<-cutoff[2,1];c2<-cutoff[2,2];c3<-cutoff[2,3];c4<-cutoff[2,4]
  mu_trunc<-cutoff[2,5]; se_trunc<-cutoff[2,6]
  
  ### 1. Estimation(Phi_0 : Proportion of null)
  ### 1.1 Zero assumption
  ind_pi0<-((Zval>c1)&(Zval<c4))
  Zval_pi0<-Zval[ind_pi0]
  
  f0_pi0<-numeric(sum(ind_pi0))
  f_pi0<-numeric(sum(ind_pi0))
  f_2_pi0<-numeric(sum(ind_pi0))
  
  for(i in c(1: sum(ind_pi0))){
    f0_pi0[i]<-dnorm(Zval_pi0[i],mu_trunc,se_trunc)
    f_pi0[i]<-lookup(Zval_pi0[i],aax,den);
    f_2_pi0[i]<-lookup(Zval_pi0[i],aax_kernel,den_kernel)
  }
  
  if(side==2){
    p00<-(preman(y=c4)-preman(y=c3)+preman(y=c2)-preman(y=c1))/
      (pnorm(c4,mu_trunc,se_trunc)-pnorm(c3,mu_trunc,se_trunc)+pnorm(c2,mu_trunc,se_trunc)-pnorm(c1,mu_trunc,se_trunc))
  } else if(side==1) {
    p00<-(preman(y=c4)-preman(y=c3))/(pnorm(c4,mu_trunc,se_trunc)-pnorm(c3,mu_trunc,se_trunc))
  }
  
  ### 1.2 Estimate
  p0_1<-min(1,p00)  ## poisson area
  p0_2<-min(1,f_pi0/f0_pi0)  ## poisson point
  p0_3<-min(1,f_2_pi0/f0_pi0)  ## kernel point
  
  
  ### 2. Estimation (f, f0)
  f0<-numeric(n)
  f<-numeric(n)
  f_2<-numeric(n)
  
  for(i in 1: n){
    f0[i]<-dnorm(Zval[i],mu_trunc,se_trunc)
    f[i]<-lookup(Zval[i],aax,den);
    f_2[i]<-lookup(Zval[i],aax_kernel,den_kernel );
  }
  
  ### 3. Supplementary
  sup_mat<-matrix(0,ncol=7,nrow=n)
  rownames(sup_mat)<-seq(1:n)
  colnames(sup_mat)<-c("P_f","K_f","fdr(P_pi0*P_f)","fdr(K_pi0*P_f)",
                       "fdr(A_pi0*K_f)","fdr(P_pi0*K_f)","fdr(K_pi0 *K_f)")
  
  sup_mat[,1]<-f  ## poisson f
  sup_mat[,2]<-f_2  ## kernel f
  sup_mat[,3]<-p0_2*f0/f  ## fdr(poisson pi0 *poisson f)
  sup_mat[,4]<-p0_3*f0/f  ## fdr(kernel pi0 *poisson f)
  sup_mat[,5]<-p0_1*f0/f_2  ## fdr(Area pi0 *kernel f)
  sup_mat[,6]<-p0_2*f0/f_2  ## fdr(poisson pi0 *kernel f)
  sup_mat[,7]<-p0_3*f0/f_2  ## fdr(kernel pi0 *kernel f)

  ### 4 result
  result<-list()
  result[[1]]<-c(p0_1,p0_2,p0_3) ## pi0 (Poisson Area/Poisson/ Kernel)
  result[[2]]<-p0_1*f0/f ## fdr (Poisson area pi0 * Possion f)
  result[[3]]<-sup_mat
  names(result)<-c("pi0","fdr","sup_mat")
  
  return(result)
}


### Function for result
### table : (1~9)
### plot : (1~9)
result_func<-function(table=0,fig=0,data_num=1,alter_rate=1/2,
                      xlims=c(-mu_alter-se_alter*2,mu_alter+se_alter*2), ylims=c(0,0.60),
                      xlims2=c(1,mu_alter+se_alter*2), ylims2=c(0,0.30),
                      xlims_fdr=c(-mu_alter-se_alter,mu_alter+se_alter), ylims_fdr=c(0,1.2),
                      xlims_fdr2=c(1,mu_alter+se_alter), ylims_fdr2=c(0,0.6),
                      ylims_RMSE=c(0,0.3)){
  
  kernel_r<-kernel_result[[data_num]]
  valid_ind<-which(pval_our[,1] != 0)
  xx<-seq(-10,10,by=0.001)
  
  ### 1 True function
  ### 1.1 null
  f00<-function(xx){(1-p_alter-p_peak)*dnorm(xx)}
  
  ### 1.2 peak
  if(trn_null){
    f01<-function(xx){p_peak* dtruncnorm(xx,mu_peak,se_peak,a=-3*se_peak,b=3*se_peak)}
  } else { f01<-function(xx){p_peak*dnorm(xx,mu_peak,se_peak)} }
  
  ### 1.3 alter
  if(side==1){f1<-function(xx){p_alter*dnorm(xx,mu_alter,se_alter)}} else
  {f1<-function(xx){p_alter*alter_rate*dnorm(xx,mu_alter,se_alter)+p_alter*(1-alter_rate)*dnorm(xx,-mu_alter,se_alter)} }
  
  ### 1.4 f
  f<-function(xx){f00(xx)+f01(xx)+f1(xx)}
  
  
  ### 2 Parameter Estimation (summary and full table)
  para_t<-matrix(0,nrow=rep,ncol=12)
  para<-matrix(0,nrow=6,ncol=6)
  
  for(i in valid_ind){
    para_t[i,(1:3)]<-c(para_efron[i,c(3,1)],para_efron[i,2]^2)
    para_t[i,(4:9)]<-c(fdrres_ramos[[i]][1,3],bestfindres[i,c(3:7)])
    para_t[i,(10:12)]<-c(pval_our[i,1],cutoff[[i]][2,5],cutoff[[i]][2,6]^2)
  }
  
  para[1,]<-c(apply(para_t[valid_ind,(1:3)],2,mean),NA,NA,NA)
  para[2,]<-c(apply(para_t[valid_ind,(1:3)],2,sd),NA,NA,NA)
  para[3,]<-apply(para_t[valid_ind,(4:9)],2,mean)
  para[4,]<-apply(para_t[valid_ind,(4:9)],2,sd)
  para[5,]<-c(apply(para_t[valid_ind,(10:12)],2,mean),NA,NA,NA)
  para[6,]<-c(apply(para_t[valid_ind,(10:12)],2,sd),NA,NA,NA)
  
  para_t<-round(para_t,5);para<-round(para,5)
  colnames(pval_our)<-c("Poisson area","Poisson point","Kernel point")
  colnames(para_t)<-c("Phi0(Efron)","Mean01","Var01",
                      "Phi0(Ramos)","Mean01","Var01","Mean02","Var02","Eta",
                      "Phi0(Ours)","Mean01","Var01")
  colnames(para)<-c("Phi0","Mean01","Var01","Mean02","Var02","Eta")
  rownames(para)<-c("Estimate(Efron)","SE(Efron)","Estimate(Ramos)","SE(Ramos)","Estimate(Ours)","SE(Ours)")
  
  
  ### 3. Numerical Estimation (fdr, tpr, tnr, false positive, #reject)
  result<-matrix(0,nrow=6,ncol=5)
  
  result[1,]<-apply(fdrest_efron[valid_ind,],2,mean)
  result[2,]<-apply(fdrest_efron[valid_ind,],2,sd)
  result[3,]<-apply(fdrest_ramos[valid_ind,],2,mean)
  result[4,]<-apply(fdrest_ramos[valid_ind,],2,sd)
  result[5,]<-apply(fdrest_our[valid_ind,],2,mean)
  result[6,]<-apply(fdrest_our[valid_ind,],2,sd)

  result<-round(result,5)
  colnames(result)<-c("FDP","TPR","TNR","FP","Reject")
  rownames(result)<-c("Estimate(Efron)","SE(Efron)","Estimate(Ramos)","SE(Ramos)","Estimate(Ours)","SE(Ours)")
  
  ### 4 RMSE
  RMSE_efron<-c()
  RMSE_ramos<-c()
  RMSE_our<-c()
  # valid_ind2<-c()
  
  for(i in valid_ind){
    
    Zval<-Zval_m[[i]][,2]
    RMSE_fdr_true<-(f00(Zval)+f01(Zval))/ f(Zval)
    
    if(side == 1){
      RMSE_ind <- (RMSE_fdr_true<0.5) & (Zval>median(Zval))
    } else{
      RMSE_ind <- (RMSE_fdr_true<0.5)
    }
    
    RMSE_fdr_efron<-fdrres_efron[[i]][,2][RMSE_ind]
    RMSE_fdr_ramos<-fdrres_ramos[[i]][,2][RMSE_ind]
    RMSE_fdr_our<-fdrres_our[[i]][,2][RMSE_ind]
    
    RMSE_efron[i]<-sqrt(sum((RMSE_fdr_efron-RMSE_fdr_true[RMSE_ind])^2)/length(RMSE_fdr_true[RMSE_ind]))
    RMSE_ramos[i]<-sqrt(sum((RMSE_fdr_ramos-RMSE_fdr_true[RMSE_ind])^2)/length(RMSE_fdr_true[RMSE_ind]))
    RMSE_our[i]<-sqrt(sum((RMSE_fdr_our-RMSE_fdr_true[RMSE_ind])^2)/length(RMSE_fdr_true[RMSE_ind]))
    
    # if( is.nan(RMSE_our[i]) | is.nan(RMSE_ramos[i]) | is.nan(RMSE_efron[i]) ) 
    #   {valid_ind2[i]<-F} else {valid_ind2[i]<-T}
  }
  
  RMSE<-matrix(round(c(mean(RMSE_efron),sd(RMSE_efron),
                       mean(RMSE_ramos),sd(RMSE_ramos),
                       mean(RMSE_our),sd(RMSE_our)),5),
               nrow=2,ncol=3)
  colnames(RMSE)<-c("RMSE(Efron)","RMSE(Ramos)","RMSE(Ours)")
  rownames(RMSE)<-c("Estimate","SE")
  
  
  ### 5. cutoff
  ccc<-cutoff[[data_num]][2,]
  a_our1<-vector()
  a_our2<-vector()
  c_our1<-vector()
  c_our2<-vector()
  a_ramos<-vector()
  c_ramos<-vector()
  
  for(i in valid_ind){
    a_our1[i]<-cutoff[[i]][2,2]
    a_our2[i]<-cutoff[[i]][2,3]
    c_our1[i]<-cutoff[[i]][2,1]
    c_our2[i]<-cutoff[[i]][2,4]
    c_ramos[i]<-bestfindres[i,1]
    a_ramos[i]<-bestfindres[i,9]
  }
  c_table<-cbind(c_our1,a_our1,a_our2,c_our2,a_ramos,c_ramos)
  colnames(c_table)<-c("Ours(c1)","Ours(a1)","Ours(a2)","Ours(c2)","Ramos(a)","Ramos(c)")
  
  ### 6. f0 & fdr
  aax_data<-dengenres[[data_num]][,1]
  den_data<-dengenres[[data_num]][,2]
  para_data<-para_t[data_num,]
  
  f0_efron<-para_data[1]*dnorm(aax_data,para_data[2],sqrt(para_data[3]))
  f0_ramos<-para_data[4]*{para_data[9]*dnorm(aax_data,para_data[5],sqrt(para_data[6]))+
      (1-para_data[9])*dnorm(aax_data,para_data[7],sqrt(para_data[8]))}
  f0_our<-para_data[10]*dnorm(aax_data,para_data[11],sqrt(para_data[12]))
  
  fdr_efron<-f0_efron/den_data
  fdr_ramos<-f0_ramos/den_data
  fdr_our<-f0_our/den_data
  
  ### 7 Table & plot
  ### 7.1 Plot
  if( fig==1 | fig=="f" ){
    
    ### 7.1.1 f
    par(mfrow=c(1,1))
    main<-expression(paste("The estimated ",f))
    
    plot(aax_data,den_data,xlim=xlims,ylim = ylims,type="l",
         main=main,ylab="Density",xlab="test-stat",
         cex.axis=1.5,cex.main=2.5,cex.lab=1.5)
    lines(xx,f(xx),col=3,lwd=2,lty=2)
    legend("topright", legend = c(main,"True"),col=c(1,3),lty = c(1,2),cex=2
           ,xpd=T, lwd=2)  
    
  } else if(fig==2 | fig=="f0"){
    
    ### 7.2.2 pi0*f0
    
    par(mfrow=c(1,2))
    main<-expression(paste("The estimated ",pi[0],f[0]))
    
    plot(aax_data,f0_our,type="l",ylim = ylims,xlim=xlims, main=main,ylab="Density",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col=4,lwd=2,lty=4) 
    lines(aax_data,f0_ramos,col=3,lwd=2,lty=3)
    lines(aax_data,f0_efron,col=2,lwd=2,lty=2)
    lines(xx,f00(xx)+f01(xx),col=1,lwd=1,lty=1)
    legend("topright", legend = c("DT","Ramos","Efron","True"),col=c(4:1),lty = c(4:1),cex=1.8
           ,xpd=T, lwd=2)
    
    plot(aax_data,f0_our,type="l",ylim = ylims2,xlim=xlims2, main=main,ylab="Density",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col=4,lwd=2,lty=4) 
    lines(aax_data,f0_ramos,col=3,lwd=2,lty=3)
    lines(aax_data,f0_efron,col=2,lwd=2,lty=2)
    lines(xx,f00(xx)+f01(xx),col=1,lwd=1,lty=1)
    legend("topright", legend = c("DT","Ramos","Efron","True"),col=c(4:1),lty = c(4:1),cex=1.8
           ,xpd=T, lwd=2)
    par(mfrow=c(1,1))
    
  } else if(fig==3 | fig=="fdr"){
    
    ### 7.2.3 fdr
    par(mfrow=c(1,2))
    main<-expression("The estimated fdr")
    
    plot(aax_data,pmin(fdr_our,1),ylim = ylims_fdr,xlim=xlims_fdr,type="l",
         main=main,ylab="fdr",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col=4,lwd=2,lty=4) ## pi0 f0
    lines(aax_data,pmin(fdr_ramos,1),col=3,lwd=2,lty=3)
    lines(aax_data,pmin(fdr_efron,1),col=2,lwd=2,lty=2)
    lines(xx,(f00(xx)+f01(xx))/(f(xx)),col=1,lwd=2,lty=1)
    legend("topright", legend = c("DT","Ramos","Efron","True"),col=c(4:1),lty = c(4:1),cex=1.8
           ,xpd=T, lwd=2)
    
    plot(aax_data,fdr_our,ylim = ylims_fdr2,xlim=xlims_fdr2,type="l",main="The estimated fdr",ylab="fdr",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col=4,lwd=2,lty=4) ## pi0 f0
    lines(aax_data,pmin(fdr_ramos,1),col=3,lwd=2,lty=3)
    lines(aax_data,pmin(fdr_efron,1),col=2,lwd=2,lty=2)
    lines(xx,(f00(xx)+f01(xx))/(f00(xx)+f01(xx)+f1(xx)),col=1,lwd=2,lty=1)
    legend("topright", legend = c("DT","Ramos","Efron","True"),col=c(4:1),lty = c(4:1),cex=1.8
           ,xpd=T, lwd=2)
    
    par(mfrow=c(1,1))
    
  } else if (fig==4 | fig=="RMSE"){
    
    ### 7.2.4 RMSE Box-plot
    par(mfrow=c(1,1))
    
    boxplot(cbind(RMSE_ramos,RMSE_efron,RMSE_our),main="RMSE",ylab="RMSE",names=c( "Ramos","Efron","DT"),
            cex.axis=1.5,cex.main=2,cex.lab=1.5,ylim=ylims_RMSE,col="grey")
    
  } else if(fig ==5 | fig=="Histogram"){
    
    ### 7.2.5 Histogram
    par(mfrow=c(1,1))
    
    hist(Zval_m[[data_num]][,2],bre,ylim=ylims,xlim=xlims,freq=F,
         main="Histogram of test-statistic",xlab="test-stat",ylab="Density",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white",yaxs="i")
    if(ccc[2]==ccc[3]) {
      abline(v=c(ccc[1],ccc[4]),lty=4);  
    } else{
      abline(v=c(ccc[1],ccc[2],ccc[3],ccc[4]),lty=4);
    }
    
    lines(aax_data,f0_our, col=4,lwd=3,lty=1)
    lines(aax_data,f0_ramos,col=3,lwd=3,lty=3)
    lines(aax_data,f0_efron,col=2,lwd=3,lty=2)
    legend("topright", legend = c("DT","Ramos","Efron","Cutoff"),col=c(4:1),lty=c(1,3,2,4),cex=1.8
           ,xpd=T, lwd=2) 
    
  } else if (fig==6 | fig=="cutoff"){
    
    ### 7.2.6 cutoff plot
    
    par(mfrow=c(2,3))
    boxplot(cbind(abs(a_our1),a_our2,a_ramos),ylim=c(0,1.5),names=c("Ours(|a1|)","Ours(a2)","Ramos(a)"),
            cex=1,cex.axis=1.5,cex.main=2,cex.lab=1.5,main="Box plot")
    if(trn_null){abline(h=3*se_peak,lty=2,col=4);}
    
    hist(a_our2,100,xlim=c(0,1.5),ylim=c(0,5),yaxs="i",
         main="Ours a2",xlab="test-stat",ylab="Freq",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white")
    if(trn_null){abline(v=3*se_peak,lty=2,col=4)};
    
    hist(a_ramos,100,xlim=c(0,1.5),ylim=c(0,5),yaxs="i",
         main="Ramos a",xlab="test-stat",ylab="Freq",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white")
    if(trn_null){abline(v=3*se_peak,lty=2,col=4)};
    
    boxplot(cbind(abs(c_our1),c_our2,c_ramos),ylim=c(0,3),names=c("Ours(|c1|)","Ours(c2)","Ramos(c)"),
            cex=1,cex.axis=1.5,cex.main=2,cex.lab=1.5,main="Box plot")
    hist(c_our2,100,xlim=c(0,3),ylim=c(0,5),yaxs="i",
         main="Ours c2",xlab="test-stat",ylab="Freq",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white",yaxs="i")
    hist(c_ramos,100,xlim=c(0,3),ylim=c(0,5),yaxs="i",
         main="Ramos c",xlab="test-stat",ylab="Freq",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,col="white",yaxs="i")
    
    par(mfrow=c(1,1))

  } else if(fig==7){
    
    ### 7.2.7 Find cutoff plot
    
    par(mfrow=c(1,2))
    plot(kernel_r[,1],kernel_r[,2],xlim=xlims,type="l",
         main="Kernel density",ylab="Density",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,lwd=1)
    abline(v=c(ccc[1],ccc[4]),lty=2);
    
    plot(kernel_r[,1],kernel_r[,3],xlim=xlims,type="l",
         main="Differentiated Kernel Density",ylab="Density",xlab="test-stat",
         cex.axis=1.5,cex.main=2,cex.lab=1.5,lwd=1)
    abline(v=c(ccc[1],ccc[4]),lty=2);
    abline(h=c(ccc[7],-ccc[7]),lty=2);
    points(ccc[2],ccc[7],pch="*",cex=3,col=4)
    points(ccc[3],-ccc[7],pch="*",cex=3,col=4)
    
    par(mfrow=c(1,1))
    
  } else if(fig==8 | fig=="ROC"){
    # 
    # ### 7.2.8 ROC curve
    # par(mfrow=c(1,1))
    # 
    # ### number of alpha : 50
    # alpha_vec<-seq(0.01,0.5,0.01)
    # n_alpha<-length(alpha_vec)
    # 
    # TPR_t_our<-matrix(0,nrow=n_alpha,ncol=rep)
    # TPR_t_ramos<-matrix(0,nrow=n_alpha,ncol=rep)
    # FPR_t_our<-matrix(0,nrow=n_alpha,ncol=rep)
    # FPR_t_ramos<-matrix(0,nrow=n_alpha,ncol=rep)
    # 
    # for(i in 1:rep){
    #   fdrest_t_our<-fdrest_vec(Zval_m[[i]],fdrres_our[[i]][,c(1:3)],a=alpha_vec,c=cutoff[[i]],method=1);
    #   fdrest_t_ramos<-fdrest_vec(Zval_m[[i]],fdrres_ramos[[i]][,c(1:3)],a=alpha_vec,c=cutoff[[i]],method=2);
    #   
    #   TPR_t_our[,i]<-fdrest_t_our[2,]
    #   TPR_t_ramos[,i]<-fdrest_t_ramos[2,]
    #   FPR_t_our[,i]<- 1-fdrest_t_our[3,]
    #   FPR_t_ramos[,i]<- 1-fdrest_t_ramos[3,]
    # }   
    # 
    # TPR_our<-as.vector(TPR_t_our)
    # TPR_ramos<-as.vector(TPR_t_ramos)
    # FPR_our<-as.vector(FPR_t_our)
    # FPR_ramos<-as.vector(FPR_t_ramos)
    # 
    # par(mfrow=c(1,1))
    # plot(FPR_our,TPR_our,xlim=c(0,0.015),ylim=c(0,1),xlab="1-Specificity",ylab="Sensitivity",main="ROC plot"
    #      ,col="grey", pch=15,cex=0.8,cex.axis=1.5,cex.main=2,cex.lab=1.5)
    # par(new=T);
    # plot(FPR_ramos,TPR_ramos,xlim=c(0,0.015),ylim=c(0,1),
    #                 ann=F,axes=F,col="cyan", pch=17,cex=0.8)
    # legend("bottomright", legend = c("DT","Ramos"),
    #        col=c("black","red"),lty = c(1,1),cex=2,xpd=T, lwd=2)
    # lines(apply(FPR_t_our,1,median),apply(TPR_t_our,1,median),type="l",lwd=4,col="Black")
    # lines(apply(FPR_t_ramos,1,median),apply(TPR_t_ramos,1,median),type="l",lwd=4,col="red")
    
  } else if (fig==9){
  #   par(mfrow=c(1,1))
  #   ### 5.2.8 ROC curve
  #   
  #   ### number of alpha : 50
  #   alpha_vec<-seq(0.01,0.5,0.01)
  #   n_alpha<-length(alpha_vec)
  #   
  #   TPR_t_our<-matrix(0,nrow=n_alpha,ncol=rep)
  #   TPR_t_ramos<-matrix(0,nrow=n_alpha,ncol=rep)
  #   FPR_t_our<-matrix(0,nrow=n_alpha,ncol=rep)
  #   FPR_t_ramos<-matrix(0,nrow=n_alpha,ncol=rep)
  #   
  #   for(i in 1:rep){
  #     fdrest_t_our<-fdrest_vec(Zval_m[[i]],fdrres_our[[i]][,c(1:3)],a=alpha_vec,c=cutoff[[i]],method=1);
  #     fdrest_t_ramos<-fdrest_vec(Zval_m[[i]],fdrres_ramos[[i]][,c(1:3)],a=alpha_vec,c=cutoff[[i]],method=2);
  #     
  #     TPR_t_our[,i]<-fdrest_t_our[2,]
  #     TPR_t_ramos[,i]<-fdrest_t_ramos[2,]
  #     FPR_t_our[,i]<- 1-fdrest_t_our[3,]
  #     FPR_t_ramos[,i]<- 1-fdrest_t_ramos[3,]
  #   }   
  #   
  #   TPR_our<-as.vector(TPR_t_our)
  #   TPR_ramos<-as.vector(TPR_t_ramos)
  #   FPR_our<-as.vector(FPR_t_our)
  #   FPR_ramos<-as.vector(FPR_t_ramos)
  #   
  #   par(mfrow=c(1,1))
  #   plot(FPR_our,TPR_our,xlim=c(0,0.01),ylim=c(0,1),xlab="1-Specificity",ylab="Sensitivity",main="ROC plot"
  #        ,col="grey", pch=15,cex=0.8,cex.axis=1.5,cex.main=2,cex.lab=1.5)
  #   par(new=T);
  #   plot(FPR_ramos,TPR_ramos,xlim=c(0,0.01),ylim=c(0,1),
  #        ann=F,axes=F,col="cyan", pch=17,cex=0.8)
  #   legend("bottomright", legend = c("DT","Ramos"),
  #          col=c("black","red"),lty = c(1,1),cex=2,xpd=T, lwd=2)
  #   lines(apply(FPR_t_our,1,median),apply(TPR_t_our,1,median),type="l",lwd=4,col="Black")
  #   lines(apply(FPR_t_ramos,1,median),apply(TPR_t_ramos,1,median),type="l",lwd=4,col="red")
  #   
  #   #### 5.1 Supplement_pi0, number of no-trunctaed,
  #   # colMeans(pval_our[valid_ind,])
  #   # sum(n_trunc ==0)
  #   # # rep-sum(valid_ind & !rpl_ind_our )
  #   # 
  #   # ### 5.2 Kurtosis as Peakedness
  #   # meso<-dnorm(xx,0,1)
  #   # lepto<-dnorm(xx,0,0.66)
  #   # platy<-dnorm(xx,0,1.33)
  #   # plot(xx,meso,type = "l",ylim=c(0,0.7),xlim=c(-3.5,3.5),ylab="Density",xlab="value",main="Kurtosis as Peakedness",
  #   #      cex.main=2,cex.axis=1.5, cex.lab=1.5,lwd=2)
  #   # lines(xx,lepto,type="l",col=2,lwd=2,lty=2)
  #   # lines(xx,platy,type="l",col=4,lwd=2,lty=3)
  #   # legend("topleft",legend = c("Mesokurtic","Leptokurtic","Platykurtic"),col = c(1,2,4),lty=c(1,2,3),cex=2,lwd=3)
  }
  
  ### 5.3 table
  
  if(table==1 | table=="parameter"){
    ### 5.3.1 Parameter
    para
    
  } else if(table ==2){
    ### 5.3.2 FDR, TPR, TNR, FD, Reject 
    result
    
  } else if( table ==3 | table=="RMSE"){
    ### 5.3.3 RMSE
    RMSE
    
  } else if ( table ==4){
    ### 5.3.4 p value
    c(colMeans(pval_our[valid_ind,]),"Ramos Pi0"=para[3,1],"# Truncated"=sum(n_trunc !=0))
    
  } else if (table ==5){
    ### 5.3.5 cutoff
    c_table<-rbind(apply(c_table,2,summary),
                   apply(c_table,2,sd))
    c_table<-c_table[c(1,2,3,5,6,4,7),]
    colnames(c_table)<-c("Ours(c1)","Ours(a1)","Ours(a2)","Ours(c2)","Ramos(a)","Ramos(c)")
    rownames(c_table)<-c("Min","1st Qu","Median","3rd Qu","Max","Mean","SE")
    c_table
     
  } else if (table ==6){
    ### 5.3.6 p value (table)
    round(cbind(pval_our,"Ramos"=para_t[,4],"Efron"=para_t[,1]) ,6)
    
  } else if (table ==7){
    ### 5.3.7 Parameter (table)
    para_t
    
  } else if (table ==8){
    ### 5.3.8 Numerical study (table)
    result_t
    
  } else if (table ==9){
    ### 5.3.9 cutoff (table)
    c_table
    
  } 
}
    
    